# Universal Mod Menu (Android)

Starter project in Kotlin + Jetpack Compose.

## Abrir y compilar
1. Descarga e instala Android Studio en un ordenador.
2. Abre la carpeta `UniversalModMenu`.
3. Espera a que Gradle sincronice.
4. Conecta un dispositivo Android o inicia un emulador.
5. Pulsa Run para probar la aplicación.
6. Para generar un APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Alcance
La app ofrece perfiles, controles locales de demostración y una interfaz de configuración.
No incluye inyección, aimbot, ESP real, automatización de partidas ni evasión de anticheat.
Las opciones Aim Assist y ESP son demostraciones dentro de la propia app.
