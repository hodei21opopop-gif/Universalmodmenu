package com.example.universalmodmenu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090910)
private val Panel = Color(0xFF171725)
private val Purple = Color(0xFF9B5CFF)
private val Cyan = Color(0xFF55D6E8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UniversalMenuApp() }
    }
}

data class GameProfile(val name: String, val subtitle: String)

@Composable
fun UniversalMenuApp() {
    val games = listOf(
        GameProfile("Fortnite", "Perfil de configuración"),
        GameProfile("Roblox", "Perfil de configuración"),
        GameProfile("Minecraft", "Perfil de configuración"),
        GameProfile("Otro juego", "Perfil personalizado")
    )
    var selectedGame by remember { mutableStateOf(games.first()) }
    var tab by remember { mutableStateOf("Panel") }
    var aimAssist by remember { mutableStateOf(false) }
    var espDemo by remember { mutableStateOf(false) }
    var showFov by remember { mutableStateOf(90f) }
    var sensitivity by remember { mutableStateOf(50f) }
    var performance by remember { mutableStateOf(true) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Panel", "Juegos", "Ajustes").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            Icon(
                                when(item) {
                                    "Juegos" -> Icons.Default.SportsEsports
                                    "Ajustes" -> Icons.Default.Settings
                                    else -> Icons.Default.Dashboard
                                }, contentDescription = item
                            )
                        },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Cyan,
                            selectedTextColor = Cyan,
                            indicatorColor = Purple.copy(alpha = .2f),
                            unselectedIconColor = Color.LightGray
                        )
                    )
                }
            }
        }) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("UNIVERSAL", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("MOD MENU  •  ANDROID", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Surface(color = Purple.copy(alpha = .18f), shape = RoundedCornerShape(50)) {
                        Text("v1.0", Modifier.padding(horizontal = 13.dp, vertical = 7.dp), color = Cyan)
                    }
                }
                Spacer(Modifier.height(20.dp))
                when(tab) {
                    "Juegos" -> GamesScreen(games, selectedGame) { selectedGame = it }
                    "Ajustes" -> SettingsScreen(performance) { performance = it }
                    else -> Dashboard(
                        selectedGame, aimAssist, { aimAssist = it },
                        espDemo, { espDemo = it },
                        showFov, { showFov = it },
                        sensitivity, { sensitivity = it }
                    )
                }
            }
        }
    }
}

@Composable
fun Dashboard(
    game: GameProfile, aim: Boolean, onAim: (Boolean) -> Unit,
    esp: Boolean, onEsp: (Boolean) -> Unit,
    fov: Float, onFov: (Float) -> Unit,
    sensitivity: Float, onSensitivity: (Float) -> Unit
) {
    Text("PANEL PRINCIPAL", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Juego seleccionado", color = Color.Gray, fontSize = 12.sp)
            Text(game.name, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(game.subtitle, color = Cyan, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(14.dp))
    Text("HERRAMIENTAS DE ENTRENAMIENTO", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    FeatureSwitch("Aim Assist", "Control de demostración; no modifica juegos externos", aim, onAim)
    FeatureSwitch("ESP Demo", "Indicador visual dentro de esta aplicación", esp, onEsp)
    Spacer(Modifier.height(10.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("FOV de práctica", Modifier.weight(1f))
                Text("${fov.toInt()}°", color = Cyan, fontWeight = FontWeight.Bold)
            }
            Slider(value = fov, onValueChange = onFov, valueRange = 40f..150f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Sensibilidad", Modifier.weight(1f))
                Text("${sensitivity.toInt()}%", color = Cyan, fontWeight = FontWeight.Bold)
            }
            Slider(value = sensitivity, onValueChange = onSensitivity, valueRange = 0f..100f)
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("Estas opciones son ajustes y demostraciones locales. No inyectan código ni alteran partidas de terceros.",
        color = Color.Gray, fontSize = 11.sp)
}

@Composable
fun FeatureSwitch(title: String, detail: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(detail, color = Color.Gray, fontSize = 10.sp)
            }
            Switch(checked = checked, onCheckedChange = onChecked, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Purple))
        }
    }
}

@Composable
fun GamesScreen(games: List<GameProfile>, selected: GameProfile, onSelect: (GameProfile) -> Unit) {
    Text("SELECTOR DE JUEGOS", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        items(games) { game ->
            Card(
                Modifier.fillMaxWidth().clickable { onSelect(game) },
                colors = CardDefaults.cardColors(containerColor = if (game == selected) Purple.copy(alpha = .22f) else Panel),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SportsEsports, contentDescription = null, tint = Cyan)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(game.name, fontWeight = FontWeight.Bold)
                        Text(game.subtitle, color = Color.Gray, fontSize = 11.sp)
                    }
                    if (game == selected) Icon(Icons.Default.CheckCircle, contentDescription = "Seleccionado", tint = Cyan)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(performance: Boolean, onPerformance: (Boolean) -> Unit) {
    Text("AJUSTES", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    FeatureSwitch("Perfil de rendimiento", "Guarda tu preferencia dentro de la aplicación", performance, onPerformance)
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Información", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Universal Mod Menu es un panel independiente. Los perfiles no cambian archivos ni memoria de juegos de terceros.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
